const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DECd0Wwh.js","assets/index-RuMnWtcf.js","assets/index-DlwU_95d.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-RuMnWtcf.js";const o=r("Share",{web:()=>t(()=>import("./web-DECd0Wwh.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
