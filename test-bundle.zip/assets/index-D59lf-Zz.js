const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-D1w9H6Yp.js","assets/index-DtOzxWkU.js","assets/index-6bNbBthI.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DtOzxWkU.js";const o=r("Share",{web:()=>t(()=>import("./web-D1w9H6Yp.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
