const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-jno1AlPC.js","assets/index-D9c_ZUKQ.js","assets/index-wcNd357R.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-D9c_ZUKQ.js";const o=r("Share",{web:()=>t(()=>import("./web-jno1AlPC.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
