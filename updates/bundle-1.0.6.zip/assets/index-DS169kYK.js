const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-B4xrGQUj.js","assets/index-BUQ9qc-b.js","assets/index-CezVtXAc.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BUQ9qc-b.js";const o=r("Share",{web:()=>t(()=>import("./web-B4xrGQUj.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
