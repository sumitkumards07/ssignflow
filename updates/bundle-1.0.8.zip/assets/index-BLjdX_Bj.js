const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-YHwh7EOs.js","assets/index-Bw9GzDMr.js","assets/index-CezVtXAc.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Bw9GzDMr.js";const o=r("Share",{web:()=>t(()=>import("./web-YHwh7EOs.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
