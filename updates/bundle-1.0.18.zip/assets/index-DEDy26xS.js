const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-B8BV6Nh_.js","assets/index-DErrydj1.js","assets/index-COpx2Md2.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DErrydj1.js";import"capacitor-cli.d.ts";const i=r("Share",{web:()=>t(()=>import("./web-B8BV6Nh_.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{i as Share};
