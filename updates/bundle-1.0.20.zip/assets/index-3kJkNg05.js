const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-y-fadl_h.js","assets/index-D2bi8QPr.js","assets/index-Chc_An8P.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-D2bi8QPr.js";const o=r("Share",{web:()=>t(()=>import("./web-y-fadl_h.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
