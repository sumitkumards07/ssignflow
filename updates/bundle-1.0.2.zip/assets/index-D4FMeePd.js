const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-HW6UUpa3.js","assets/index-D82xGbsn.js","assets/index-bv4kNHsc.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-D82xGbsn.js";const o=r("Share",{web:()=>t(()=>import("./web-HW6UUpa3.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
