const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CbX3E0-z.js","assets/index-BtUV6bpr.js","assets/index-bv4kNHsc.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BtUV6bpr.js";const o=r("Share",{web:()=>t(()=>import("./web-CbX3E0-z.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
