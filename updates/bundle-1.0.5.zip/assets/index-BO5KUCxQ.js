const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-QXo2dk7P.js","assets/index-ChiFQV_1.js","assets/index-Csx2cYf_.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-ChiFQV_1.js";const o=r("Share",{web:()=>t(()=>import("./web-QXo2dk7P.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
