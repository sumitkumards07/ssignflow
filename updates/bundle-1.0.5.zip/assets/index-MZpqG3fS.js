const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-eNOD7RwY.js","assets/index-BSCq8XNp.js","assets/index-D2EgkXzx.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BSCq8XNp.js";const o=r("Share",{web:()=>t(()=>import("./web-eNOD7RwY.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
