const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DVsub7M9.js","assets/index-BpoiYfsa.js","assets/index-BuncTWsj.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BpoiYfsa.js";const o=r("Share",{web:()=>t(()=>import("./web-DVsub7M9.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
