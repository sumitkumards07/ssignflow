const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-D6aFWQa3.js","assets/index-CE031Kxm.js","assets/index-DgfSWAdK.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CE031Kxm.js";import"capacitor-cli.d.ts";const i=r("Share",{web:()=>t(()=>import("./web-D6aFWQa3.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{i as Share};
