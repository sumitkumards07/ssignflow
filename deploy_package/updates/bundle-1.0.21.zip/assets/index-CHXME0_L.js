const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-OOlhb4WP.js","assets/index-CViKE1yB.js","assets/index-Chc_An8P.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CViKE1yB.js";const o=r("Share",{web:()=>t(()=>import("./web-OOlhb4WP.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
