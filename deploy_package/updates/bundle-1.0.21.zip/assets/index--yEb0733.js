const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CQt5mkX3.js","assets/index-DrUY1ew9.js","assets/index-DgfSWAdK.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DrUY1ew9.js";const o=r("Share",{web:()=>t(()=>import("./web-CQt5mkX3.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
