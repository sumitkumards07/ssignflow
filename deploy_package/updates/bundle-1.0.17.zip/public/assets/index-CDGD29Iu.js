const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DTx_Rh90.js","assets/index-UrfJjN5v.js","assets/index-Chc_An8P.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-UrfJjN5v.js";const o=r("Share",{web:()=>t(()=>import("./web-DTx_Rh90.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
