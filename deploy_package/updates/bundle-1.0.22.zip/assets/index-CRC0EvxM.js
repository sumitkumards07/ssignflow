const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BBwmwgcO.js","assets/index-BIhb-Bxy.js","assets/index-Chc_An8P.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BIhb-Bxy.js";const o=r("Share",{web:()=>t(()=>import("./web-BBwmwgcO.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
