const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DRWIsRlI.js","assets/index-BMQXFsVq.js","assets/index-COpx2Md2.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BMQXFsVq.js";const o=r("Share",{web:()=>t(()=>import("./web-DRWIsRlI.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
