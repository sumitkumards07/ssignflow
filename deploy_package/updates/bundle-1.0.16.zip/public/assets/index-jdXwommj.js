const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-nVfd2Wt4.js","assets/index-rCCOpPsy.js","assets/index-Chc_An8P.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-rCCOpPsy.js";const o=r("Share",{web:()=>t(()=>import("./web-nVfd2Wt4.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
