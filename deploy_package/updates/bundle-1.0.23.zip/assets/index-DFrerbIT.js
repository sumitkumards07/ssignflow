const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BqNGT4Mb.js","assets/index-Dlo51GoP.js","assets/index-Chc_An8P.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Dlo51GoP.js";const o=r("Share",{web:()=>t(()=>import("./web-BqNGT4Mb.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
