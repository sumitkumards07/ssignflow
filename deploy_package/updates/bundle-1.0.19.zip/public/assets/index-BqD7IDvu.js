const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BKIWe62q.js","assets/index-Byxd93Qy.js","assets/index-Chc_An8P.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Byxd93Qy.js";const o=r("Share",{web:()=>t(()=>import("./web-BKIWe62q.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
