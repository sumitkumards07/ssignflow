const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CnwlIj9y.js","assets/index-CjuTrbJD.js","assets/index-BkAu0Qk7.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CjuTrbJD.js";const o=r("Share",{web:()=>t(()=>import("./web-CnwlIj9y.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
