const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BbKJwdtY.js","assets/index-Y5RY1B05.js","assets/index-bv4kNHsc.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Y5RY1B05.js";const o=r("Share",{web:()=>t(()=>import("./web-BbKJwdtY.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
