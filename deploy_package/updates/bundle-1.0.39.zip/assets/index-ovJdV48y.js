const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BXa6cs9g.js","assets/index-CkIgFQjM.js","assets/index-bv4kNHsc.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CkIgFQjM.js";const o=r("Share",{web:()=>t(()=>import("./web-BXa6cs9g.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
