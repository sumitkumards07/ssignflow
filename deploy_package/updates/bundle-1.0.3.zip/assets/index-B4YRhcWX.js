const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CzHtk6kd.js","assets/index-CiQ5qT-4.js","assets/index-bv4kNHsc.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CiQ5qT-4.js";const o=r("Share",{web:()=>t(()=>import("./web-CzHtk6kd.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
