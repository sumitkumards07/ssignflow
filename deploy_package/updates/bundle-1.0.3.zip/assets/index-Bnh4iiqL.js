const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C6hDuCQq.js","assets/index-C26mnmIU.js","assets/index-bv4kNHsc.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-C26mnmIU.js";const o=r("Share",{web:()=>t(()=>import("./web-C6hDuCQq.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
