const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-B0hLWcRs.js","assets/index-BDY7A3M4.js","assets/index-CyDPbwfQ.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BDY7A3M4.js";const o=r("Share",{web:()=>t(()=>import("./web-B0hLWcRs.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
