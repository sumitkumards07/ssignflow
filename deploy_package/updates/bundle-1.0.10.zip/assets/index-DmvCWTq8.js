const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Dk05R8j2.js","assets/index-DEmWcXUH.js","assets/index-CezVtXAc.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DEmWcXUH.js";const o=r("Share",{web:()=>t(()=>import("./web-Dk05R8j2.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
