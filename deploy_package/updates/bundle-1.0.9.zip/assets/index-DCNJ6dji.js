const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-j2N_MQpr.js","assets/index-KsLl4dGU.js","assets/index-DgfSWAdK.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-KsLl4dGU.js";const o=r("Share",{web:()=>t(()=>import("./web-j2N_MQpr.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
