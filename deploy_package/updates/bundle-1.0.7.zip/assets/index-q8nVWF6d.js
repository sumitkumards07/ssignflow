const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CdSv0DlH.js","assets/index-BX7S_LDl.js","assets/index-DgfSWAdK.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BX7S_LDl.js";const o=r("Share",{web:()=>t(()=>import("./web-CdSv0DlH.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
